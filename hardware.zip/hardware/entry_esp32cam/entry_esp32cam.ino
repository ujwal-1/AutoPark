#include "esp_camera.h"
#include <ArduinoJson.h>
#include <ESP32Servo.h>
#include <WiFi.h>
#include <WiFiClient.h>

// =====================================================
// AUTOPARK ENTRY ESP32-CAM FIRMWARE (SERVO BOOM BARRIER)
// =====================================================

// =====================================================
// 1. WI-FI CREDENTIALS
// Fill these in for your own network before flashing. Never commit real
// credentials.
// =====================================================
const char *WIFI_SSID = "ANAND N";
const char *WIFI_PASSWORD = "8971878807";

// =====================================================
// 2. BACKEND SERVER CONFIGURATION
// Laptop running FastAPI on port 8000
// =====================================================
const char *SERVER_HOST = "192.168.0.104";
const uint16_t SERVER_PORT = 8000;
const char *SERVER_PATH = "/api/detection/entry";

// Frame capture interval (milliseconds)
const unsigned long CAPTURE_INTERVAL_MS = 5000;

// =====================================================
// 3. HARDWARE OUTPUT PINS
// Note: Servos are now centrally handled by the NodeMCU ESP8266 controller!
// If servos were directly on ESP32-CAM: pin 12. Set to -1 when using ESP8266.
// =====================================================
#define SERVO_PIN -1
#define BUZZER_PIN -1

Servo entryBarrierServo;

// =====================================================
// BOOM BARRIER & BUZZER TRIGGER FUNCTIONS
// =====================================================
void beepBuzzer(int count = 2, int durationMs = 120) {
  if (BUZZER_PIN < 0)
    return;
  for (int i = 0; i < count; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(durationMs);
    digitalWrite(BUZZER_PIN, LOW);
    delay(100);
  }
}

void openEntryBoomBarrier() {
  Serial.println("[BOOM BARRIER] 🚗 LIFTING ENTRY BARRIER (90°)...");
  entryBarrierServo.write(90); // Lift barrier arm
  beepBuzzer(1, 100);
  delay(5000); // Hold open for 5 seconds for car to drive through
  Serial.println("[BOOM BARRIER] 🛑 LOWERING ENTRY BARRIER (0°)...");
  entryBarrierServo.write(0); // Lower barrier arm
}

// =====================================================
// 4. AI-THINKER ESP32-CAM PINOUT (OV2640 / OV3660)
// =====================================================
#define PWDN_GPIO_NUM 32
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM 0
#define SIOD_GPIO_NUM 26
#define SIOC_GPIO_NUM 27

#define Y9_GPIO_NUM 35
#define Y8_GPIO_NUM 34
#define Y7_GPIO_NUM 39
#define Y6_GPIO_NUM 36
#define Y5_GPIO_NUM 21
#define Y4_GPIO_NUM 19
#define Y3_GPIO_NUM 18
#define Y2_GPIO_NUM 5

#define VSYNC_GPIO_NUM 25
#define HREF_GPIO_NUM 23
#define PCLK_GPIO_NUM 22

unsigned long lastCaptureTime = 0;

// =====================================================
// CAMERA SETUP
// Board: "ESP32 Dev Module" | PSRAM: "Disabled"
// Your board has faulty PSRAM — all allocation uses internal DRAM.
// =====================================================
void setupCamera() {
  // CRITICAL: zero-initialize to clear garbage in fields we don't set
  camera_config_t config;
  memset(&config, 0, sizeof(camera_config_t));

  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = Y2_GPIO_NUM;
  config.pin_d1       = Y3_GPIO_NUM;
  config.pin_d2       = Y4_GPIO_NUM;
  config.pin_d3       = Y5_GPIO_NUM;
  config.pin_d4       = Y6_GPIO_NUM;
  config.pin_d5       = Y7_GPIO_NUM;
  config.pin_d6       = Y8_GPIO_NUM;
  config.pin_d7       = Y9_GPIO_NUM;
  config.pin_xclk     = XCLK_GPIO_NUM;
  config.pin_pclk     = PCLK_GPIO_NUM;
  config.pin_vsync    = VSYNC_GPIO_NUM;
  config.pin_href     = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn     = PWDN_GPIO_NUM;
  config.pin_reset    = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;  // 20MHz standard
  config.pixel_format = PIXFORMAT_JPEG;
  config.fb_count     = 1;
  config.grab_mode    = CAMERA_GRAB_WHEN_EMPTY;
  config.fb_location  = CAMERA_FB_IN_DRAM;

  // ── Auto-fallback: VGA → HVGA → QVGA → QQVGA (all internal DRAM) ──
  const framesize_t sizes[]    = { FRAMESIZE_VGA, FRAMESIZE_HVGA, FRAMESIZE_QVGA, FRAMESIZE_QQVGA };
  const char       *labels[]   = { "VGA 640x480",  "HVGA 480x320", "QVGA 320x240", "QQVGA 160x120" };
  const int         qualities[] = { 10,             10,              12,              12 };
  const int         numSizes   = 4;
  bool cameraOk = false;

  Serial.printf("[CAMERA] Free DMA: %u bytes | Largest block: %u bytes\n",
                heap_caps_get_free_size(MALLOC_CAP_DMA),
                heap_caps_get_largest_free_block(MALLOC_CAP_DMA));

  for (int i = 0; i < numSizes && !cameraOk; i++) {
    config.frame_size   = sizes[i];
    config.jpeg_quality = qualities[i];

    Serial.printf("[CAMERA] Attempt %d: %s (DRAM, 1 buf)...\n", i + 1, labels[i]);
    esp_err_t err = esp_camera_init(&config);

    if (err == ESP_OK) {
      Serial.printf("[CAMERA] >> %s init SUCCESS!\n", labels[i]);
      cameraOk = true;
    } else {
      Serial.printf("[CAMERA] >> %s failed (0x%x)\n", labels[i], err);
      esp_camera_deinit();
      delay(100);
    }
  }

  if (!cameraOk) {
    Serial.println("[CAMERA ERROR] ALL resolutions failed! Check ribbon cable or replace board.");
    return;
  }

  // Adjust sensor orientation (handles both OV3660 and OV2640)
  sensor_t *sensor = esp_camera_sensor_get();
  if (sensor != NULL) {
    if (sensor->id.PID == OV3660_PID) {
      Serial.println("[CAMERA] OV3660 sensor detected.");
      sensor->set_vflip(sensor, 1);
      sensor->set_brightness(sensor, 1);
      sensor->set_saturation(sensor, -1);
    } else {
      Serial.println("[CAMERA] OV2640 sensor detected.");
      sensor->set_vflip(sensor, 1);
      sensor->set_hmirror(sensor, 0);
    }
  }

  Serial.println("[CAMERA] Initialized and ready to capture.");
}

// =====================================================
// CAPTURE & STREAM IMAGE TO FASTAPI BACKEND
// =====================================================
bool captureAndSendFrame() {
  Serial.println();
  Serial.println("---------------------------------------------");
  Serial.println("[ENTRY CAMERA] Capturing image...");

  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) {
    delay(100);
    fb = esp_camera_fb_get();
  }
  if (!fb) {
    Serial.println("[ENTRY CAMERA ERROR] Frame capture failed! Check ribbon cable, USB power, or enable PSRAM in Tools.");
    return false;
  }

  Serial.printf("[ENTRY CAMERA] Image captured: %u bytes (%dx%d)\n",
                (unsigned int)fb->len, fb->width, fb->height);

  // Check Wi-Fi connection
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[WIFI] Disconnected! Reconnecting...");
    WiFi.reconnect();
    esp_camera_fb_return(fb);
    return false;
  }

  WiFiClient client;
  client.setTimeout(15000); // 15 seconds bounded connection timeout

  Serial.printf("[HTTP] Connecting to http://%s:%u%s ...\n", SERVER_HOST,
                SERVER_PORT, SERVER_PATH);
  if (!client.connect(SERVER_HOST, SERVER_PORT)) {
    Serial.println("[HTTP ERROR] Backend connection failed! Verify laptop IP "
                   "and port 8000.");
    esp_camera_fb_return(fb);
    return false;
  }

  // Multipart form data boundaries
  const char *boundary = "AutoParkBoundaryEntry99";
  const char *ending = "\r\n--AutoParkBoundaryEntry99--\r\n";

  char partHeader[256];
  int partHeaderLen = snprintf(partHeader, sizeof(partHeader),
                               "--%s\r\n"
                               "Content-Disposition: form-data; name=\"file\"; "
                               "filename=\"entry.jpg\"\r\n"
                               "Content-Type: image/jpeg\r\n\r\n",
                               boundary);

  size_t endingLen = strlen(ending);
  size_t contentLength = (size_t)partHeaderLen + fb->len + endingLen;

  // Send HTTP POST headers
  client.printf("POST %s HTTP/1.1\r\n", SERVER_PATH);
  client.printf("Host: %s:%u\r\n", SERVER_HOST, SERVER_PORT);
  client.printf("Content-Type: multipart/form-data; boundary=%s\r\n", boundary);
  client.printf("Content-Length: %u\r\n", (unsigned int)contentLength);
  client.println("Connection: close");
  client.println();

  // Stream multipart body directly from frame buffer (0 heap allocation!)
  client.write((const uint8_t *)partHeader, partHeaderLen);
  client.write(fb->buf, fb->len);
  client.write((const uint8_t *)ending, endingLen);

  // Free camera frame buffer immediately
  esp_camera_fb_return(fb);

  Serial.println(
      "[HTTP] Frame streamed to backend. Waiting for ANPR evaluation...");

  // Read HTTP Response Status Line
  unsigned long startWait = millis();
  while (!client.available() && client.connected() &&
         (millis() - startWait < 15000)) {
    delay(20);
  }

  if (!client.available()) {
    Serial.println("[HTTP ERROR] No response from backend within timeout!");
    client.stop();
    return false;
  }

  String statusLine = client.readStringUntil('\n');
  statusLine.trim();
  Serial.print("[HTTP STATUS] ");
  Serial.println(statusLine);

  // Skip HTTP headers to get JSON response body
  while (client.connected() || client.available()) {
    String headerLine = client.readStringUntil('\n');
    headerLine.trim();
    if (headerLine.length() == 0)
      break; // Blank line marks end of headers
  }

  // Read JSON response body (bounded, no heap lockup)
  String responseBody = "";
  unsigned long bodyStart = millis();
  while ((client.connected() || client.available()) &&
         (millis() - bodyStart < 4000)) {
    while (client.available()) {
      char c = client.read();
      responseBody += c;
    }
    delay(5);
  }
  client.stop();

  Serial.println("[BACKEND RESPONSE JSON]");
  Serial.println(responseBody);

  // Parse JSON response (supports ArduinoJson v6 and v7)
#if ARDUINOJSON_VERSION_MAJOR >= 7
  JsonDocument doc;
#else
  DynamicJsonDocument doc(2048);
#endif
  DeserializationError err = deserializeJson(doc, responseBody);

  if (!err) {
    const char *status = doc["status"] | "unknown";
    const char *slot = doc["slot"] | "none";
    const char *plate = doc["plate_number"] | "none";
    float confidence = doc["confidence"] | 0.0;
    bool trigger_buzzer = doc["trigger_buzzer"] | false;
    const char *message = doc["message"] | "";

    Serial.println();
    Serial.println("=========================================");
    Serial.println("          AUTOPARK ENTRY RESULT          ");
    Serial.println("=========================================");
    Serial.printf("Status:         %s\n", status);
    Serial.printf("Assigned Slot:  %s\n", slot);
    Serial.printf("Plate Number:   %s\n", plate);
    Serial.printf("Confidence:     %.1f%%\n", confidence * 100.0);
    Serial.printf("Message:        %s\n", message);
    Serial.println("=========================================");

    bool open_barrier = doc["open_barrier"] | false;

    // Trigger physical Boom Barrier Servo upon authorized slot assignment
    if (open_barrier || trigger_buzzer) {
      Serial.printf(
          "[BOOM BARRIER] ACCESS GRANTED FOR SLOT %s — LIFTING GATE\n", slot);
      openEntryBoomBarrier();
    } else {
      Serial.println("[BOOM BARRIER] GATE LOCKED (0°) — ACCESS NOT GRANTED");
    }
  } else {
    Serial.printf("[JSON ERROR] Parse failed (%s). Raw response: %s\n",
                  err.c_str(), responseBody.c_str());
  }

  return true;
}

// =====================================================
// SETUP
// =====================================================
void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("==================================================");
  Serial.println("   AUTOPARK ENTRY GATE ESP32-CAM NODE");
  Serial.println("==================================================");

  // 1. INITIALIZE CAMERA FIRST (CRITICAL: reserves DMA frame buffer before WiFi takes RAM!)
  setupCamera();

  // 2. CONNECT TO WI-FI AFTER CAMERA HAS SECURED ITS MEMORY
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.printf("[WIFI] Connecting to '%s'", WIFI_SSID);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 40) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("[WIFI] Connected successfully!");
    Serial.print("[WIFI] ESP32-CAM Entry IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("[WIFI ERROR] Connection failed! Check SSID and password.");
  }

  Serial.println("[SYSTEM] Entry camera ready. Capturing every 5 seconds.");
  lastCaptureTime = millis();
}

// =====================================================
// MAIN LOOP
// =====================================================
void loop() {
  // Bounded auto-reconnect if Wi-Fi connection drops
  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lastReconnectAttempt = 0;
    if (millis() - lastReconnectAttempt > 5000) {
      lastReconnectAttempt = millis();
      Serial.println("[WIFI] Connection lost. Reconnecting to Wi-Fi...");
      WiFi.disconnect();
      WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    }
    delay(100);
    return;
  }

  // Continuous capture cycle approximately every 5 seconds
  if (millis() - lastCaptureTime >= CAPTURE_INTERVAL_MS) {
    captureAndSendFrame();
    lastCaptureTime =
        millis(); // Reset 5s timer AFTER capture & transmission finishes
  }

  delay(20);
}